﻿using System;
using System.Collections.Generic;

namespace ChampionsLeague.Entities;

public partial class OrderLine
{
    public int LineId { get; set; }

    public int OrderId { get; set; }

    public int ProductId { get; set; }

    public virtual Order Order { get; set; } = null!;

    public virtual Product Product { get; set; } = null!;
}
